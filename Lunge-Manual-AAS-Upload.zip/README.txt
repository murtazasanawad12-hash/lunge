Manual AAS source project for Fabric Minecraft 26.3
Hold G while slot 1 is selected; each new left mouse press triggers one 1 -> 8 -> 1 swap.
No swap without G or when another slot is selected.
Remove the original Auto Attribute Swap mod to avoid conflicts.
Requires Fabric API 0.165.0+26.3 and Fabric Loader >=0.19.5.
Build: Java 21 and Gradle 9.2.1; run `gradle build`.
GitHub: upload the extracted files (including the hidden .github folder); use Actions > Build Manual AAS > Run workflow, then download the artifact.
IMPORTANT: Source has not been compiled or tested in Minecraft; API compatibility and actual in-game behavior are not verified.

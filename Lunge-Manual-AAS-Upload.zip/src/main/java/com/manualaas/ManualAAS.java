package com.manualaas;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;

public class ManualAAS implements ClientModInitializer {
    private static final KeyMapping HOLD_G = KeyMappingHelper.registerKeyMapping(
        new KeyMapping("key.manualaas.hold", InputConstants.Type.KEYBOARD, 71, KeyMapping.Category.MISC));

    @Override public void onInitializeClient() { }

    public static void onLeftClick() {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.getConnection() == null || client.screen != null) return;
        if (!HOLD_G.isDown() || client.player.getInventory().getSelectedSlot() != 0) return;
        client.player.getInventory().setSelectedSlot(7);
        client.getConnection().send(new ServerboundSetCarriedItemPacket(7));
        client.player.getInventory().setSelectedSlot(0);
        client.getConnection().send(new ServerboundSetCarriedItemPacket(0));
    }
}

# Manual AAS (Minecraft 26.3 / Fabric)

Hold **G** while hotbar slot **1** is selected. Each **left mouse press** triggers a slot **1 → 8 → 1** swap. Otherwise no swap occurs.

## GitHub upload
Upload the contents of this extracted ZIP (including the hidden `.github` folder) to the root of your `lunge` repository. GitHub Actions will attempt to compile the mod on push to `main`. If the build succeeds, open **Actions → latest Build Manual AAS → Artifacts** to get the JAR. Install only the normal JAR (not a `-sources` JAR) in your Fabric mods folder, alongside Fabric API. Remove the original AAS mod to avoid conflicts.

## Verification status
The source ZIP has been checked for completeness and ZIP integrity. This project has **not** been compiled or tested in Minecraft in this environment; GitHub Actions may report mapping or dependency errors. A successful build is not proof of correct in-game behavior. Minecraft's own input processing or server anti-cheat can also affect swapping.
